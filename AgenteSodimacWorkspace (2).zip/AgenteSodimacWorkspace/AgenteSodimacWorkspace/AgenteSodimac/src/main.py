from fastapi import FastAPI
from pydantic import BaseModel
from src.agent.sodimac_agent import SodimacAgent

app = FastAPI(title="Agente Sodimac")
agent = SodimacAgent()

class Query(BaseModel):
    question: str

@app.post("/query")
async def query_agent(data: Query):
    response = agent.answer_question(data.question)
    return {"response": response}