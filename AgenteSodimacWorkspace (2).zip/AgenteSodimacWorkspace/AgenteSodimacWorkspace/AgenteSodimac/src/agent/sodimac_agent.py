import os
from langchain.llms import OpenAI
from langchain.chains import RetrievalQA
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import Chroma
from dotenv import load_dotenv

load_dotenv()

class SodimacAgent:
    def __init__(self):
        self.embeddings = OpenAIEmbeddings()
        self.vectordb = Chroma(persist_directory="chroma_db", embedding_function=self.embeddings)
        retriever = self.vectordb.as_retriever(search_kwargs={"k": 5})
        self.llm = OpenAI(temperature=0.1)
        self.qa_chain = RetrievalQA.from_chain_type(
            llm=self.llm,
            chain_type="stuff",
            retriever=retriever
        )

    def answer_question(self, query: str):
        return self.qa_chain.run(query)