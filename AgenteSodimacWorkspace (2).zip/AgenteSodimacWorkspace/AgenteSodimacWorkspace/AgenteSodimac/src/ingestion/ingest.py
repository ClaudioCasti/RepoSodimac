import os
from langchain.document_loaders import TextLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import Chroma
from dotenv import load_dotenv

load_dotenv()

def ingest_documents():
    docs_path = "documents"
    if not os.path.exists(docs_path):
        os.makedirs(docs_path)
        print(f"📁 Carpeta creada: {docs_path}")
        return

    print("📚 Cargando documentos desde:", docs_path)
    documents = []
    for filename in os.listdir(docs_path):
        if filename.endswith(".txt"):
            loader = TextLoader(os.path.join(docs_path, filename))
            documents.extend(loader.load())

    if not documents:
        print("⚠️ No se encontraron documentos para procesar.")
        return

    print("🔄 Procesando documentos...")
    splitter = RecursiveCharacterTextSplitter(chunk_size=600, chunk_overlap=100)
    texts = splitter.split_documents(documents)

    print("🧠 Generando embeddings y creando base de datos...")
    embeddings = OpenAIEmbeddings()
    vectordb = Chroma.from_documents(documents=texts, embedding=embeddings, persist_directory="chroma_db")
    vectordb.persist()
    print("✅ Ingesta completada. Base de datos lista en 'chroma_db/'.")

if __name__ == "__main__":
    ingest_documents()