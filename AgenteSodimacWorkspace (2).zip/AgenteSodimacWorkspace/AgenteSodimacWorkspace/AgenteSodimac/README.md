# 🤖 Agente Sodimac - Asistente de Consultas Inteligente

Este proyecto implementa un **Agente Funcional con RAG (Retrieval-Augmented Generation)** 
para mejorar la atención al cliente de Sodimac. Utiliza **LangChain**, **ChromaDB**, 
y **OpenAI GPT** para responder preguntas sobre productos, compatibilidades y políticas.

## 🚀 Instalación

1. Clonar el repositorio o ejecutar el script `scaffold_agente_sodimac.py`.
2. Crear un entorno virtual:
   ```bash
   python -m venv venv
   venv\Scripts\activate  # Windows
   ```
3. Instalar dependencias:
   ```bash
   pip install -r requirements.txt
   ```
4. Copiar `.env.example` a `.env` y agregar tu clave de OpenAI.

## 📘 Uso
- Agrega documentos PDF o TXT en la carpeta `documents/`.
- Ejecuta el script de ingesta:
  ```bash
  python src/ingestion/ingest.py
  ```
- Levanta la API:
  ```bash
  uvicorn src.main:app --reload
  ```

## 📂 Estructura
```
AgenteSodimac/
├── src/
│   ├── agent/
│   ├── tools/
│   ├── memory/
│   ├── ingestion/
│   └── main.py
├── documents/
├── .env
├── requirements.txt
└── README.md
```

## 📚 Referencias
- LangChain Docs: https://docs.langchain.com
- ChromaDB: https://docs.trychroma.com
- OpenAI API: https://platform.openai.com/docs