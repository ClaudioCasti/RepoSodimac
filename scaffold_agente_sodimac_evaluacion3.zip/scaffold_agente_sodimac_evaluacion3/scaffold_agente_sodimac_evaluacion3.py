import os
from pathlib import Path
from textwrap import dedent

# ================================
# CONFIGURACIÓN INICIAL
# ================================
BASE_DIR = Path.cwd() / "AgenteSodimac"

folders = [
    "src",
    "src/agent",
    "src/tools",
    "src/memory",
    "src/ingestion",
    "src/utils",
    "documents",
    "tests"
]

files_content = {
    "requirements.txt": dedent("""
        langchain
        openai
        chromadb
        fastapi
        uvicorn
        python-dotenv
        pydantic
    """).strip(),

    ".env.example": dedent("""
        OPENAI_API_KEY=tu_api_key_aqui
    """).strip(),

    "README.md": dedent("""
        # 🤖 Agente Sodimac - Asistente de Consultas Inteligente

        Este proyecto implementa un **Agente Funcional con RAG (Retrieval-Augmented Generation)** 
        para mejorar la atención al cliente de Sodimac. Utiliza **LangChain**, **ChromaDB**, 
        y **OpenAI GPT** para responder preguntas sobre productos, compatibilidades y políticas.

        ## 🚀 Instalación

        1. Clonar el repositorio o ejecutar el script `scaffold_agente_sodimac.py`.
        2. Crear un entorno virtual:
           ```bash
           python -m venv venv
           venv\\Scripts\\activate  # Windows
           ```
        3. Instalar dependencias:
           ```bash
           pip install -r requirements.txt
           ```
        4. Copiar `.env.example` a `.env` y agregar tu clave de OpenAI.

        ## 📘 Uso
        - Agrega documentos PDF o TXT en la carpeta `documents/`.
        - Ejecuta el script de ingesta:
          ```bash
          python src/ingestion/ingest.py
          ```
        - Levanta la API:
          ```bash
          uvicorn src.main:app --reload
          ```

        ## 📂 Estructura
        ```
        AgenteSodimac/
        ├── src/
        │   ├── agent/
        │   ├── tools/
        │   ├── memory/
        │   ├── ingestion/
        │   └── main.py
        ├── documents/
        ├── .env
        ├── requirements.txt
        └── README.md
        ```

        ## 📚 Referencias
        - LangChain Docs: https://docs.langchain.com
        - ChromaDB: https://docs.trychroma.com
        - OpenAI API: https://platform.openai.com/docs
    """).strip(),

    "src/main.py": dedent("""
        from fastapi import FastAPI
        from pydantic import BaseModel
        from src.agent.sodimac_agent import SodimacAgent

        app = FastAPI(title="Agente Sodimac")
        agent = SodimacAgent()

        class Query(BaseModel):
            question: str

        @app.post("/query")
        async def query_agent(data: Query):
            response = agent.answer_question(data.question)
            return {"response": response}
    """).strip(),

    "src/agent/sodimac_agent.py": dedent("""
        import os
        from langchain.llms import OpenAI
        from langchain.chains import RetrievalQA
        from langchain.embeddings import OpenAIEmbeddings
        from langchain.vectorstores import Chroma
        from dotenv import load_dotenv

        load_dotenv()

        class SodimacAgent:
            def __init__(self):
                self.embeddings = OpenAIEmbeddings()
                self.vectordb = Chroma(persist_directory="chroma_db", embedding_function=self.embeddings)
                retriever = self.vectordb.as_retriever(search_kwargs={"k": 5})
                self.llm = OpenAI(temperature=0.1)
                self.qa_chain = RetrievalQA.from_chain_type(
                    llm=self.llm,
                    chain_type="stuff",
                    retriever=retriever
                )

            def answer_question(self, query: str):
                return self.qa_chain.run(query)
    """).strip(),

    "src/ingestion/ingest.py": dedent("""
        import os
        from langchain.document_loaders import TextLoader
        from langchain.text_splitter import RecursiveCharacterTextSplitter
        from langchain.embeddings import OpenAIEmbeddings
        from langchain.vectorstores import Chroma
        from dotenv import load_dotenv

        load_dotenv()

        def ingest_documents():
            docs_path = "documents"
            if not os.path.exists(docs_path):
                os.makedirs(docs_path)
                print(f"📁 Carpeta creada: {docs_path}")
                return

            print("📚 Cargando documentos desde:", docs_path)
            documents = []
            for filename in os.listdir(docs_path):
                if filename.endswith(".txt"):
                    loader = TextLoader(os.path.join(docs_path, filename))
                    documents.extend(loader.load())

            if not documents:
                print("⚠️ No se encontraron documentos para procesar.")
                return

            print("🔄 Procesando documentos...")
            splitter = RecursiveCharacterTextSplitter(chunk_size=600, chunk_overlap=100)
            texts = splitter.split_documents(documents)

            print("🧠 Generando embeddings y creando base de datos...")
            embeddings = OpenAIEmbeddings()
            vectordb = Chroma.from_documents(documents=texts, embedding=embeddings, persist_directory="chroma_db")
            vectordb.persist()
            print("✅ Ingesta completada. Base de datos lista en 'chroma_db/'.")

        if __name__ == "__main__":
            ingest_documents()
    """).strip(),
}

# ================================
# CREACIÓN DE ESTRUCTURA
# ================================
print("🚧 Generando estructura de proyecto Agente Sodimac...\n")

for folder in folders:
    path = BASE_DIR / folder
    os.makedirs(path, exist_ok=True)
    print(f"📁 Carpeta creada: {path}")

for filename, content in files_content.items():
    file_path = BASE_DIR / filename
    file_path.parent.mkdir(parents=True, exist_ok=True)
    with open(file_path, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"📄 Archivo creado: {file_path}")

print("\n✅ Proyecto 'AgenteSodimac' generado correctamente.")
print("➡️ Próximo paso: crea tu entorno virtual y ejecuta la ingesta de documentos.")
